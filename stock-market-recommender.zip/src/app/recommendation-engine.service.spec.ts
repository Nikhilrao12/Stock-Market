/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { RecommendationEngineService } from './recommendation-engine.service';

describe('Service: RecommendationEngine', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RecommendationEngineService]
    });
  });

  it('should ...', inject([RecommendationEngineService], (service: RecommendationEngineService) => {
    expect(service).toBeTruthy();
  }));
});
