import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { RecommendationEngineService } from './recommendation-engine.service';
export interface StockData {
  stockSymbol: string;
  socialMediaCount: number;
  date: Date;
  price: number;
  recommendationRating: string;
}


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'stock-market-recommender';
  displayedColumns: string[] = ['stockSymbol', 'socialMediaCount', 'date', 'price','recommendationRating'];
  totalData: StockData[] = [];
  dataSource : StockData[] = [];;

  stockSymbolInput = "";
  range = new FormGroup({
    start: new FormControl(null),
    end: new FormControl(null),
  });

  constructor(private recommendationEngineService : RecommendationEngineService){
    this.recommendationEngineService.getStockData().subscribe(data => {
      this.totalData = data;
      this.dataSource = this.totalData;
    })
  }

  filterBySymbol(){
      this.dataSource = this.totalData.filter(x => x.stockSymbol.toLowerCase().includes(this.stockSymbolInput.toLowerCase()));
  }

  filterByDate() {
    let filterData: any[] = this.totalData;
    if(this.stockSymbolInput.toLowerCase().trim().length > 0 ){
      filterData = this.totalData.filter(x => x.stockSymbol.toLowerCase().includes(this.stockSymbolInput.toLowerCase()));
    }

    if(this.range.controls['start'].value){
      filterData = filterData.filter(x => x.date >= this.range.controls['start'].value);
    }
    if(this.range.controls['end'].value){
      filterData = filterData.filter(x => x.date <= this.range.controls['end'].value);
    }

    this.dataSource = filterData;
  }


}
