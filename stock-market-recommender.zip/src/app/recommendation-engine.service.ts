import { Injectable } from '@angular/core';

import { Observable, of } from 'rxjs';
import { StockData } from './app.component';

@Injectable({
  providedIn: 'root'
})
export class RecommendationEngineService {

stockSymbolList =   ['INDUSINDBK', 'CIPLA', 'AXISBANK', 'KOTAKBANK', 'MARUTI', 'SUNPHARMA', 'DIVISLAB', 'POWERGRID', 'ICICIBANK', 'BHARTIARTL', 'ITC', 'NTPC', 'JSWSTEEL', 'APOLLOHOSP', 'HINDUNILVR', 'ONGC', 'TATASTEEL', 'BAJFINANCE', 'COALINDIA', 'TITAN', 'SBILIFE', 'HDFCBANK', 'LT', 'SBIN', 'HDFC', 'EICHERMOT', 'BAJAJFINSV', 'DRREDDY', 'SHREECEM', 'BAJAJ-AUTO', 'HCLTECH', 'ASIANPAINT', 'BRITANNIA', 'HINDALCO', 'RELIANCE', 'TCS', 'ADANIPORTS', 'NESTLEIND', 'WIPRO', 'TATAMOTORS', 'BPCL', 'M&M', 'HDFCLIFE', 'HEROMOTOCO', 'GRASIM', 'INFY', 'ULTRACEMCO', 'TECHM', 'TATACONSUM', 'UPL']
constructor() { }

public getStockData(): Observable<any>{
return of(this.generateData());
}


public generateData() {
  let stockData: StockData[] = [];
  const now = new Date();
  var daysOfYear = [];
  for (var d = new Date(2022, 0, 1); d <= now; d.setDate(d.getDate() + 1)) {
      this.stockSymbolList.forEach(x => {
        let rec = Math.floor(Math.random() * 3) + 1;

        let stock: StockData = {
          stockSymbol: x,
          socialMediaCount: Math.floor(Math.random() * 100),
          date: new Date(d),
          price:  Math.random() * 200.5,
          recommendationRating: rec == 1 ? 'buy' : rec == 2 ? 'sell' : 'hold'
        }
        stockData.push(stock);
      })

  }
  return stockData;
}

}
